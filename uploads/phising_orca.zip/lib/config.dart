import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AppConfig {
  static const String _configUrl = 
      'https://raw.githubusercontent.com/DixzzXD88/ytta/main/config.json';
  
  static String baseUrl = '';
  
  static Future<void> loadConfig() async {
    final prefs = await SharedPreferences.getInstance();
    
    try {
      final response = await http.get(Uri.parse(_configUrl));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        baseUrl = data['baseUrl'] ?? '';
        
        await prefs.setString('baseUrl', baseUrl);
        print('✅ Config loaded from GitHub: $baseUrl');
        return;
      }
    } catch (e) {
      print('⚠️ Failed to load from GitHub: $e');
    }
    
    // Fallback ke local
    baseUrl = prefs.getString('baseUrl') ?? '';
    print('✅ Config loaded from local storage: $baseUrl');
  }
}